export default function Footer() {
    return (
        <footer className="footer">
            <p>&copy; 2023 Job Platform Admin Dashboard. Version 1.0.0</p>
        </footer>
    );
}